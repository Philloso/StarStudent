 $(".ball").hide().show("slow");
 
 $(".navbar.navbar-default.navbar-fixed-top").hide().fadeIn("slow");

 $(".device").hide().fadeToggle("slow");

 $(".panel").hide().show("slow");

 $(".col-sm-6").hide().show("slow");